// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ethnic_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Ethnic _$EthnicFromJson(Map<String, dynamic> json) => Ethnic(
      id: json['id'] as String,
      name: json['name'] as String,
    );

Map<String, dynamic> _$EthnicToJson(Ethnic instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
