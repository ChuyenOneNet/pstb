class FirstAidsViewModel {
  //this is called “model”
  final int id;
  final String? img;
  final String? title;
  const FirstAidsViewModel({required this.id, required this.img, this.title});
}