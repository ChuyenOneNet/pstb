// class GetBookingModel{
//   int status
// }