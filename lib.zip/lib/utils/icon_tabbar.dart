class TabIcon {
  static String medicalUnit = 'assets/icons/new_icon_personal/ic_medical_unit.svg';
  static String homeInactive = 'assets/icons/tabbar/tabbar_home_outline.svg';
  static String homeActive = 'assets/icons/tabbar/tabbar_home_filled.svg';
  static String calendarInactive = 'assets/icons/tabbar/calendar.svg';
  static String notificationActive = 'assets/icons/tabbar/notification_bell-fill.svg';
  static String userInactive = 'assets/icons/tabbar/user.svg';
  static String communityActive = 'assets/icons/tabbar/community.svg';
  static String homeSearch = 'assets/icons/tabbar/search.svg';
  static String homeBell = 'assets/icons/tabbar/notification_bell.svg';
}