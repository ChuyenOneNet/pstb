class CanvasEnum {
  static const String headerHome = 'assets/canvas/vector_home.svg';
  static const String canvasBottom = 'assets/canvas/Rectangle451.svg';
  static const String signup_success = 'assets/canvas/Canvans_Signup.svg';
  static const String homeHeaderBg = 'assets/canvas/home_header.svg';
  static const String loginHeader = 'assets/canvas/login_header.svg';
  static const String community = 'assets/canvas/community.svg';
  static const String personal = 'assets/canvas/personal.svg';
}
