import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

dynamic l10n(BuildContext context) {
  return AppLocalizations.of(context);
}
