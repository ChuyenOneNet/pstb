class Keys {
  static const String signAuthorizationKey = "sys.admin:1";
}
