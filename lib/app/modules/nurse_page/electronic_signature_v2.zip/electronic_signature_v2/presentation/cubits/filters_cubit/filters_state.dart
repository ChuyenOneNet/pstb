import 'package:equatable/equatable.dart';
import 'package:pstb/app/models/department_model.dart';
import 'package:pstb/app/models/document_type_model.dart';

enum FiltersStatus { initial, loading, success, failure }

class FiltersState extends Equatable {
  final FiltersStatus status;
  final List<DepartmentModel> departments;
  final List<TypeDocumentModel> docTypes;
  final String? error;

  const FiltersState({
    this.status = FiltersStatus.initial,
    this.departments = const [],
    this.docTypes = const [],
    this.error,
  });

  FiltersState copyWith({
    FiltersStatus? status,
    List<DepartmentModel>? departments,
    List<TypeDocumentModel>? docTypes,
    String? error,
  }) =>
      FiltersState(
        status: status ?? this.status,
        departments: departments ?? this.departments,
        docTypes: docTypes ?? this.docTypes,
        error: error,
      );

  @override
  List<Object?> get props => [status, departments, docTypes, error];
}
