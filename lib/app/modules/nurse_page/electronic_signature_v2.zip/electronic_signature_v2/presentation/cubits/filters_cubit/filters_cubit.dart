import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';

import '../../../data/repositories/signature_repository.dart';
import 'filters_state.dart';

final _sl = GetIt.instance;

class FiltersCubit extends Cubit<FiltersState> {
  FiltersCubit() : super(const FiltersState());

  SignatureRepository get _repo => _sl<SignatureRepository>();

  Future<void> load({String? keyword}) async {
    emit(state.copyWith(status: FiltersStatus.loading));
    try {
      final deps = await _repo.getDepartments(keyword: keyword);
      final types = await _repo.getTypeDocuments(keyword: keyword);
      emit(state.copyWith(
        status: FiltersStatus.success,
        departments: deps.items ?? [],
        docTypes: types.items ?? [],
      ));
    } catch (e) {
      emit(state.copyWith(status: FiltersStatus.failure, error: e.toString()));
    }
  }
}
