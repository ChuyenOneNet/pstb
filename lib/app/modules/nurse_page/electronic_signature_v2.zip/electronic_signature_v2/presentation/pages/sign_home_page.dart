import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pstb/app/modules/nurse_page/electronic_signature_v2/presentation/pages/sign_document_detail_page.dart';

import '../../../../../../constant/color.dart';
import '../../data/filter_signature_model.dart';
import '../../data/repositories/signature_repository.dart';
import '../cubits/documents_cubit/documents_cubit.dart';
import '../cubits/documents_cubit/documents_state.dart';
import '../cubits/filters_cubit/filters_cubit.dart';
import '../cubits/filters_cubit/filters_state.dart';
import '../cubits/roles_cubit/roles_cubit.dart';
import '../cubits/patients_cubit/patients_cubit.dart';
import '../cubits/patients_cubit/patients_state.dart';
import '../cubits/sign_document_detail_cubit/sign_document_detail_cubit.dart';
import '../widgets/filter_bar.dart';
import '../widgets/doc_tile.dart';
import '../widgets/empty_view.dart';
import '../../data/signing_status.dart' show mapStatusKeyToInt;
import '../cubits/sign_action_cubit/sign_action_cubit.dart';
import 'package:pstb/app/models/patient_model.dart';
import 'package:pstb/app/models/document_type_model.dart';
import 'package:pstb/app/models/department_model.dart';
import 'package:pstb/app/models/sign_roles_model.dart';
import 'package:get_it/get_it.dart';

import '../widgets/patient_picker_remote.dart';
import '../widgets/searchable_picker.dart';
import 'sign_document_type_page.dart';

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pstb/app/modules/nurse_page/electronic_signature_v2/presentation/pages/sign_document_detail_page.dart';
import '../../../../../../constant/color.dart';
import '../../data/filter_signature_model.dart';
import '../../data/repositories/signature_repository.dart';
import '../cubits/documents_cubit/documents_cubit.dart';
import '../cubits/documents_cubit/documents_state.dart';
import '../cubits/filters_cubit/filters_cubit.dart';
import '../cubits/filters_cubit/filters_state.dart';
import '../cubits/roles_cubit/roles_cubit.dart';
import '../cubits/patients_cubit/patients_cubit.dart';
import '../cubits/patients_cubit/patients_state.dart';
import '../cubits/sign_document_detail_cubit/sign_document_detail_cubit.dart';
import '../widgets/filter_bar.dart';
import '../widgets/doc_tile.dart';
import '../widgets/empty_view.dart';
import '../../data/signing_status.dart' show mapStatusKeyToInt;
import '../cubits/sign_action_cubit/sign_action_cubit.dart';
import 'package:pstb/app/models/patient_model.dart';
import 'package:pstb/app/models/document_type_model.dart';
import 'package:pstb/app/models/department_model.dart';
import 'package:pstb/app/models/sign_roles_model.dart';
import 'package:get_it/get_it.dart';
import '../widgets/patient_picker_remote.dart';
import '../widgets/searchable_picker.dart';
import 'sign_document_type_page.dart';

class SignHomePage extends StatefulWidget {
  final String userName;
  const SignHomePage({super.key, required this.userName});

  @override
  State<SignHomePage> createState() => _SignHomePageState();
}

class _SignHomePageState extends State<SignHomePage> {
  final _searchCtrl = TextEditingController();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    context.read<FiltersCubit>().load();
    _searchCtrl.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchCtrl.removeListener(_onSearchChanged);
    _searchCtrl.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  List<TypeDocumentModel> _filterTypes(List<TypeDocumentModel> types) {
    final q = _searchCtrl.text.trim().toLowerCase();
    if (q.isEmpty) return types;
    return types
        .where((t) => (t.name ?? '').toLowerCase().contains(q))
        .toList();
  }

  void _onSearchChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Ký số điện tử',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                letterSpacing: -0.5,
              ),
            ),
            Text(
              'Xin chào, ${widget.userName}',
              style: TextStyle(
                fontWeight: FontWeight.w400,
                fontSize: 13,
                color: Colors.white.withOpacity(0.85),
              ),
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(68),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: _buildSearchBar(),
          ),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF1E7FFF), Color(0xFF0D47A1)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
      ),
      body: BlocBuilder<FiltersCubit, FiltersState>(
        builder: (context, st) {
          if (st.status == FiltersStatus.loading) {
            return _buildLoadingState();
          }

          if (st.status == FiltersStatus.failure) {
            return EmptyView(
              title: 'Lỗi khi tải',
              message:
                  st.error ?? 'Không thể tải loại tài liệu. Vui lòng thử lại.',
              icon: Icons.error_outline,
              action: ElevatedButton.icon(
                onPressed: () => context.read<FiltersCubit>().load(),
                icon: const Icon(
                  Icons.refresh,
                  color: AppColors.whiteColor,
                ),
                label: const Text(
                  'Thử lại',
                  style: TextStyle(color: AppColors.whiteColor),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1E7FFF),
                ),
              ),
            );
          }

          final types = _filterTypes(st.docTypes);

          if (types.isEmpty) {
            return const EmptyView(
              title: 'Không có loại tài liệu',
              message: 'Không tìm thấy loại tài liệu nào.',
              icon: Icons.folder_open,
            );
          }

          return RefreshIndicator(
            onRefresh: () async => context.read<FiltersCubit>().load(),
            color: const Color(0xFF1E7FFF),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: types.length,
              itemBuilder: (context, index) {
                final type = types[index];
                return _DocumentTypeItem(
                  type: type,
                  userName: widget.userName,
                  index: index,
                  onTap: () async {
                    Navigator.of(context).push(
                      PageRouteBuilder(
                        pageBuilder: (context, animation, secondaryAnimation) =>
                            MultiBlocProvider(
                          providers: [
                            BlocProvider(create: (_) => FiltersCubit()..load()),
                            BlocProvider(create: (_) => DocumentsCubit()),
                            BlocProvider(create: (_) => RolesCubit()),
                            BlocProvider(create: (_) => SignActionCubit()),
                            BlocProvider(create: (_) => PatientsCubit()),
                          ],
                          child: SignDocumentTypePage(
                            userName: widget.userName,
                            docType: type,
                          ),
                        ),
                        transitionsBuilder:
                            (context, animation, secondaryAnimation, child) {
                          return SlideTransition(
                            position: Tween<Offset>(
                              begin: const Offset(1, 0),
                              end: Offset.zero,
                            ).animate(
                              CurvedAnimation(
                                parent: animation,
                                curve: Curves.easeOutCubic,
                              ),
                            ),
                            child: child,
                          );
                        },
                      ),
                    );
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildSearchBar() {
    return SizedBox(
      height: 48,
      child: TextField(
        controller: _searchCtrl,
        textInputAction: TextInputAction.search,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 15,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          hintText: 'Tìm loại tài liệu...',
          hintStyle: TextStyle(
            color: Colors.white.withOpacity(0.6),
            fontSize: 14,
          ),
          prefixIcon: Icon(
            Icons.search,
            color: Colors.white.withOpacity(0.7),
            size: 20,
          ),
          suffixIcon: _searchCtrl.text.isEmpty
              ? null
              : IconButton(
                  icon: Icon(
                    Icons.close,
                    color: Colors.white.withOpacity(0.7),
                    size: 20,
                  ),
                  onPressed: () {
                    _searchCtrl.clear();
                    _onSearchChanged();
                  },
                ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Colors.white.withOpacity(0.3),
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Colors.white.withOpacity(0.2),
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(
              color: Colors.white,
              width: 2,
            ),
          ),
          filled: true,
          fillColor: Colors.white.withOpacity(0.12),
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(vertical: 0),
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      itemCount: 6,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: _SkeletonLoader(),
        );
      },
    );
  }
}

//
// class SignHomePage extends StatefulWidget {
//   final String userName;
//   const SignHomePage({super.key, required this.userName});
//
//   @override
//   State<SignHomePage> createState() => _SignHomePageState();
// }
//
// class _SignHomePageState extends State<SignHomePage> {
//   final _searchCtrl = TextEditingController();
//   Timer? _debounce;
//
//   @override
//   void initState() {
//     super.initState();
//     context.read<FiltersCubit>().load();
//     _searchCtrl.addListener(_onSearchChanged);
//   }
//
//   @override
//   void dispose() {
//     _searchCtrl.removeListener(_onSearchChanged);
//     _searchCtrl.dispose();
//     _debounce?.cancel();
//     super.dispose();
//   }
//
//   List<TypeDocumentModel> _filterTypes(List<TypeDocumentModel> types) {
//     final q = _searchCtrl.text.trim().toLowerCase();
//     if (q.isEmpty) return types;
//     return types
//         .where((t) => (t.name ?? '').toLowerCase().contains(q))
//         .toList();
//   }
//
//   void _onSearchChanged() {
//     _debounce?.cancel();
//     _debounce = Timer(const Duration(milliseconds: 300), () {
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         elevation: 0,
//         title: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Text(
//               'Ký số điện tử',
//               style: TextStyle(
//                 fontWeight: FontWeight.bold,
//                 fontSize: 22,
//                 letterSpacing: -0.5,
//               ),
//             ),
//             Text(
//               'Xin chào, ${widget.userName}',
//               style: TextStyle(
//                 fontWeight: FontWeight.w400,
//                 fontSize: 13,
//                 color: Colors.white.withOpacity(0.85),
//               ),
//             ),
//           ],
//         ),
//         bottom: PreferredSize(
//           preferredSize: const Size.fromHeight(68),
//           child: Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//             child: _buildSearchBar(),
//           ),
//         ),
//         flexibleSpace: Container(
//           decoration: const BoxDecoration(
//             gradient: LinearGradient(
//               colors: [Color(0xFF1E7FFF), Color(0xFF0D47A1)],
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//             ),
//           ),
//         ),
//         backgroundColor: Colors.transparent,
//         foregroundColor: Colors.white,
//       ),
//       body: BlocBuilder<FiltersCubit, FiltersState>(
//         builder: (context, st) {
//           if (st.status == FiltersStatus.loading) {
//             return _buildLoadingState();
//           }
//
//           if (st.status == FiltersStatus.failure) {
//             return EmptyView(
//               title: 'Lỗi khi tải',
//               message:
//                   st.error ?? 'Không thể tải loại tài liệu. Vui lòng thử lại.',
//               icon: Icons.error_outline,
//               action: ElevatedButton.icon(
//                 onPressed: () => context.read<FiltersCubit>().load(),
//                 icon: const Icon(
//                   Icons.refresh,
//                   color: AppColors.whiteColor,
//                 ),
//                 label: const Text(
//                   'Thử lại',
//                   style: TextStyle(color: AppColors.whiteColor),
//                 ),
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: const Color(0xFF1E7FFF),
//                 ),
//               ),
//             );
//           }
//
//           final types = _filterTypes(st.docTypes);
//
//           if (types.isEmpty) {
//             return const EmptyView(
//               title: 'Không có loại tài liệu',
//               message: 'Không tìm thấy loại tài liệu nào.',
//               icon: Icons.folder_open,
//             );
//           }
//
//           return RefreshIndicator(
//             onRefresh: () async => context.read<FiltersCubit>().load(),
//             color: const Color(0xFF1E7FFF),
//             child: ListView.builder(
//               padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//               itemCount: types.length,
//               itemBuilder: (context, index) {
//                 final type = types[index];
//                 return _DocumentTypeItem(
//                   type: type,
//                   userName: widget.userName,
//                   index: index,
//                   onTap: () async {
//                     Navigator.of(context).push(
//                       PageRouteBuilder(
//                         pageBuilder: (context, animation, secondaryAnimation) =>
//                             MultiBlocProvider(
//                           providers: [
//                             BlocProvider(create: (_) => FiltersCubit()..load()),
//                             BlocProvider(create: (_) => DocumentsCubit()),
//                             BlocProvider(create: (_) => RolesCubit()),
//                             BlocProvider(create: (_) => SignActionCubit()),
//                             BlocProvider(create: (_) => PatientsCubit()),
//                           ],
//                           child: SignDocumentTypePage(
//                             userName: widget.userName,
//                             docType: type,
//                           ),
//                         ),
//                         transitionsBuilder:
//                             (context, animation, secondaryAnimation, child) {
//                           return SlideTransition(
//                             position: Tween<Offset>(
//                               begin: const Offset(1, 0),
//                               end: Offset.zero,
//                             ).animate(
//                               CurvedAnimation(
//                                 parent: animation,
//                                 curve: Curves.easeOutCubic,
//                               ),
//                             ),
//                             child: child,
//                           );
//                         },
//                       ),
//                     );
//                   },
//                 );
//               },
//             ),
//           );
//         },
//       ),
//     );
//   }
//
//   Widget _buildSearchBar() {
//     return SizedBox(
//       height: 48,
//       child: TextField(
//         controller: _searchCtrl,
//         textInputAction: TextInputAction.search,
//         style: const TextStyle(
//           color: Colors.white,
//           fontSize: 15,
//           fontWeight: FontWeight.w500,
//         ),
//         decoration: InputDecoration(
//           hintText: 'Tìm loại tài liệu...',
//           hintStyle: TextStyle(
//             color: Colors.white.withOpacity(0.6),
//             fontSize: 14,
//           ),
//           prefixIcon: Icon(
//             Icons.search,
//             color: Colors.white.withOpacity(0.7),
//             size: 20,
//           ),
//           suffixIcon: _searchCtrl.text.isEmpty
//               ? null
//               : IconButton(
//                   icon: Icon(
//                     Icons.close,
//                     color: Colors.white.withOpacity(0.7),
//                     size: 20,
//                   ),
//                   onPressed: () {
//                     _searchCtrl.clear();
//                     _onSearchChanged();
//                   },
//                 ),
//           border: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(12),
//             borderSide: BorderSide(
//               color: Colors.white.withOpacity(0.3),
//             ),
//           ),
//           enabledBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(12),
//             borderSide: BorderSide(
//               color: Colors.white.withOpacity(0.2),
//             ),
//           ),
//           focusedBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(12),
//             borderSide: const BorderSide(
//               color: Colors.white,
//               width: 2,
//             ),
//           ),
//           filled: true,
//           fillColor: Colors.white.withOpacity(0.12),
//           isDense: true,
//           contentPadding: const EdgeInsets.symmetric(vertical: 0),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildLoadingState() {
//     return ListView.builder(
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//       itemCount: 6,
//       itemBuilder: (context, index) {
//         return Padding(
//           padding: const EdgeInsets.only(bottom: 8),
//           child: _SkeletonLoader(),
//         );
//       },
//     );
//   }
// }
//
class _DocumentTypeItem extends StatefulWidget {
  final TypeDocumentModel type;
  final String userName;
  final int index;
  final VoidCallback onTap;

  const _DocumentTypeItem({
    required this.type,
    required this.userName,
    required this.index,
    required this.onTap,
  });

  @override
  State<_DocumentTypeItem> createState() => _DocumentTypeItemState();
}

class _DocumentTypeItemState extends State<_DocumentTypeItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;
  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(-0.3, 0),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    _fadeAnimation = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );
    _animationController.value = 0.6;
    Future.delayed(Duration(milliseconds: widget.index * 50), () {
      if (mounted) {
        _animationController.forward();
      }
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _slideAnimation,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: _CompactListTile(
          type: widget.type,
          userName: widget.userName,
          onTap: widget.onTap,
        ),
      ),
    );
  }
}

class _CompactListTile extends StatefulWidget {
  final TypeDocumentModel type;
  final String userName;
  final VoidCallback onTap;

  const _CompactListTile({
    required this.type,
    required this.userName,
    required this.onTap,
  });

  @override
  State<_CompactListTile> createState() => _CompactListTileState();
}

class _CompactListTileState extends State<_CompactListTile> {
  int _documentCount = 0;
  bool _loadingCount = true;

  @override
  void initState() {
    super.initState();
    _loadDocumentCount();
  }

  Future<void> _loadDocumentCount() async {
    try {
      final filter = FilterSignatureModelV2(
        userName: widget.userName,
        documentTypeCode: widget.type.code,
        pageSize: 1,
      ).firstPage(size: 1);

      final repo = GetIt.instance<SignatureRepository>();
      final result = await repo.getDocumentsWithFilterV1(filter);

      if (mounted) {
        setState(() {
          _documentCount = result.total ?? (result.items?.length ?? 0);
          _loadingCount = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _documentCount = 0;
          _loadingCount = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        elevation: 1,
        shadowColor: Colors.black.withOpacity(0.08),
        child: InkWell(
          onTap: widget.onTap,
          borderRadius: BorderRadius.circular(10),
          child: Container(
            height: 56,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: const Color(0xFF1E7FFF).withOpacity(0.1),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                // Icon
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF1E7FFF).withOpacity(0.15),
                        const Color(0xFF1E7FFF).withOpacity(0.06),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: const Color(0xFF1E7FFF).withOpacity(0.1),
                      width: 1,
                    ),
                  ),
                  child: const Icon(
                    Icons.description_outlined,
                    color: Color(0xFF1E7FFF),
                    size: 22,
                  ),
                ),
                const SizedBox(width: 12),
                // Name and count
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        widget.type.name ?? widget.type.code ?? 'N/A',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1F2937),
                        ),
                      ),
                      // const SizedBox(height: 2),
                      // Text(
                      //   widget.type.code ?? '',
                      //   maxLines: 1,
                      //   overflow: TextOverflow.ellipsis,
                      //   style: TextStyle(
                      //     fontSize: 12,
                      //     fontWeight: FontWeight.w400,
                      //     color: Colors.grey.shade500,
                      //   ),
                      // ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                // Document count badge
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF1E7FFF).withOpacity(0.12),
                        const Color(0xFF1E7FFF).withOpacity(0.04),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: const Color(0xFF1E7FFF).withOpacity(0.2),
                      width: 0.8,
                    ),
                  ),
                  child: _loadingCount
                      ? SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 1.5,
                            valueColor: const AlwaysStoppedAnimation(
                              Color(0xFF1E7FFF),
                            ),
                          ),
                        )
                      : Text(
                          _documentCount.toString(),
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF1E7FFF),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SkeletonLoader extends StatefulWidget {
  @override
  State<_SkeletonLoader> createState() => _SkeletonLoaderState();
}

class _SkeletonLoaderState extends State<_SkeletonLoader>
    with SingleTickerProviderStateMixin {
  late AnimationController _shimmerController;

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.grey.shade200,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          _ShimmerBox(
            width: 40,
            height: 40,
            borderRadius: 8,
            animation: _shimmerController,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _ShimmerBox(
                  width: 120,
                  height: 14,
                  borderRadius: 4,
                  animation: _shimmerController,
                ),
                const SizedBox(height: 6),
                _ShimmerBox(
                  width: 80,
                  height: 10,
                  borderRadius: 4,
                  animation: _shimmerController,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          _ShimmerBox(
            width: 40,
            height: 26,
            borderRadius: 6,
            animation: _shimmerController,
          ),
        ],
      ),
    );
  }
}

class _ShimmerBox extends StatelessWidget {
  final double width;
  final double height;
  final double borderRadius;
  final AnimationController animation;

  const _ShimmerBox({
    required this.width,
    required this.height,
    required this.borderRadius,
    required this.animation,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            gradient: LinearGradient(
              begin: Alignment(-1.0 - (animation.value * 2), 0),
              end: Alignment(1.0 + (animation.value * 2), 0),
              colors: [
                Colors.grey.shade200,
                Colors.grey.shade100,
                Colors.grey.shade200,
              ],
              stops: const [0.0, 0.5, 1.0],
            ),
          ),
        );
      },
    );
  }
}
